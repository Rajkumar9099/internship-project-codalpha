// Mock authentication function
function login() {
    // Normally, you'd use OAuth or other authentication methods here
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({ userId: '12345', token: 'fake-token' });
        }, 1000);
    });
}

document.getElementById('login-btn').addEventListener('click', async () => {
    const user = await login();
    if (user) {
        document.getElementById('dashboard').style.display = 'block';
        document.getElementById('login-btn').style.display = 'none';
        fetchFeeds(user.token);
    }
});
