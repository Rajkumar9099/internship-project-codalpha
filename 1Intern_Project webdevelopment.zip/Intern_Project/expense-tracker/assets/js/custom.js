document.addEventListener('DOMContentLoaded', () => {
    const expenseForm = document.getElementById('expense-form');
    const expenseList = document.getElementById('expenses');
    const descriptionInput = document.getElementById('description');
    const amountInput = document.getElementById('amount');

    let expenses = JSON.parse(localStorage.getItem('expenses')) || [];

    function renderExpenses() {
        expenseList.innerHTML = '';
        expenses.forEach((expense, index) => {
            const li = document.createElement('li');
            li.classList.add('expense-item');
            li.innerHTML = `
                <span>${expense.description}: ₹ ${expense.amount.toFixed(2)}</span>
                <div>
                    <button class="edit" onclick="editExpense(${index})">Edit</button>
                    <button onclick="deleteExpense(${index})">Delete</button>
                </div>
            `;
            expenseList.appendChild(li);
        });
    }

    function saveExpenses() {
        localStorage.setItem('expenses', JSON.stringify(expenses));
    }

    window.editExpense = function(index) {
        const expense = expenses[index];
        descriptionInput.value = expense.description;
        amountInput.value = expense.amount;
        expenseForm.removeEventListener('submit', addExpense);
        expenseForm.addEventListener('submit', function updateExpense(e) {
            e.preventDefault();
            expenses[index] = {
                description: descriptionInput.value,
                amount: parseFloat(amountInput.value)
            };
            saveExpenses();
            renderExpenses();
            expenseForm.removeEventListener('submit', updateExpense);
            expenseForm.addEventListener('submit', addExpense);
            descriptionInput.value = '';
            amountInput.value = '';
        });
    }

    window.deleteExpense = function(index) {
        expenses.splice(index, 1);
        saveExpenses();
        renderExpenses();
    }

    function addExpense(e) {
        e.preventDefault();
        const description = descriptionInput.value;
        const amount = parseFloat(amountInput.value);

        if (description && !isNaN(amount)) {
            expenses.push({ description, amount });
            saveExpenses();
            renderExpenses();
            descriptionInput.value = '';
            amountInput.value = '';
        }
    }

    expenseForm.addEventListener('submit', addExpense);
    renderExpenses();
});
