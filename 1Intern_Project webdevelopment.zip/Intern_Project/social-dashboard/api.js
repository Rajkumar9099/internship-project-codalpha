// Mock functions to fetch feeds
async function fetchFacebookFeed(token) {
    // Simulate fetching data from Facebook API
    return [
        { content: 'Facebook post 1' },
        { content: 'Facebook post 2' }
    ];
}

async function fetchTwitterFeed(token) {
    // Simulate fetching data from Twitter API
    return [
        { content: 'Twitter tweet 1' },
        { content: 'Twitter tweet 2' }
    ];
}

async function fetchInstagramFeed(token) {
    // Simulate fetching data from Instagram API
    return [
        { content: 'Instagram post 1' },
        { content: 'Instagram post 2' }
    ];
}

async function fetchFeeds(token) {
    const facebookFeed = await fetchFacebookFeed(token);
    const twitterFeed = await fetchTwitterFeed(token);
    const instagramFeed = await fetchInstagramFeed(token);

    displayFeed('facebook-posts', facebookFeed);
    displayFeed('twitter-tweets', twitterFeed);
    displayFeed('instagram-posts', instagramFeed);
}

function displayFeed(elementId, posts) {
    const ul = document.getElementById(elementId);
    ul.innerHTML = '';
    posts.forEach(post => {
        const li = document.createElement('li');
        li.textContent = post.content;
        ul.appendChild(li);
    });
}
